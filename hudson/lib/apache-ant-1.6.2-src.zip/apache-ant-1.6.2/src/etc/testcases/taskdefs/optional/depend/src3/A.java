public class A {
    static private class Inner {
        static private class Inner2 extends B {
        }
    }
}

