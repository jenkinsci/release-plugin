package uk.ltd.getahead.dwr.test;

import uk.ltd.getahead.dwr.convert.BeanConverter;

/**
 * For demo purposes
 * @author Joe Walker [joe at getahead dot ltd dot uk]
 */
public class TestBean2Converter extends BeanConverter
{
}
